Step 1:
- Create a python virtual environment

Step 2:
- pip install -r requirements.txt

Step 3:
- py app.py

Step 3: (Alternative)
- python app.py